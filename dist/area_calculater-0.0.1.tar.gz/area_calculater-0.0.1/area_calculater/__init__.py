from .figures import (
    Figure,
    CircleFigure,
    TriangleFigure,
)
