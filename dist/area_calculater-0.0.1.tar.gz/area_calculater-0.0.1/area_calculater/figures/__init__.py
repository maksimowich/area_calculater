from .Figure import Figure
from .CircleFigure import CircleFigure
from .TriangleFigure import TriangleFigure
